/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shortest_path_matrix;

import java.util.Scanner;

/**
 *
 * @author visha
 */
public class Shortest_Path_Matrix {

    /**
     * @param args the command line arguments
     */
    static Sequence[] s=new Sequence[100];
    static int sum=0;
    static int sequenceIndex=0;
    static int r,c;
    public static void main(String[] args) {
        // TODO code application logic here
        Sequence min;
          for(int i=0;i<100;i++)
          {
              s[i]=new Sequence("",0);
          }
        String sequence;
        Scanner sc=new Scanner(System.in);
        r=sc.nextInt();
        c=sc.nextInt();
        int t[][]=new int[r][c];
        for(int i=0;i<r;i++)
            for(int j=0;j<c;j++)
                t[i][j]=sc.nextInt();
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                System.out.print(t[i][j]+" ");
            }
            System.out.println("");
        }
        
        System.out.println("The possible paths are");
        traverse(t,0,0,"",0);
        for(int i=0;i<sequenceIndex;i++)
        {
            System.out.println(s[i].sequence+"-"+s[i].sum);
        }
        
        min=s[0];
        for(int i=1;i<sequenceIndex;i++)
        {
            if(min.sum > s[i].sum)
                min = s[i];
        }
        System.out.println("Shortest path is en jaami");
        System.out.println(min.sequence+"-"+min.sum);
    }    


    static void traverse(int[][] t,int i,int j,String ans,int result)
    {   
         if(i==r-1 && j==c-1)
         {
             s[sequenceIndex].sequence=ans+t[i][j];
             s[sequenceIndex].sum=result+t[i][j];
             sequenceIndex++;
             return;   
         }
         if(i!=(r-1))
         traverse(t,i+1,j,ans+t[i][j]+",",result+t[i][j]);
       //  System.out.println(t[i][j]);
         if(j!=c -1)
         traverse(t,i,j+1,ans+t[i][j]+",",result+t[i][j]);

    }
    
}
class Sequence{
    public String sequence;
    public int sum;

    public Sequence(String sequence, int sum) {
        this.sequence = sequence;
        this.sum = sum;
    }
    
}