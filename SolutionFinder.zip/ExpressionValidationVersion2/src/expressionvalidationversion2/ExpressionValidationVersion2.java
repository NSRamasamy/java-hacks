/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expressionvalidationversion2;

import java.util.Scanner;

/**
 *
 * @author vishak-ramasamy
 */
public class ExpressionValidationVersion2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n;
        int key;
        String symbol = "+-*/";
        Scanner sc=new Scanner(System.in);
        key=sc.nextInt();
        n=sc.nextInt();
        int a[]=new int[n];
        boolean[] b=new boolean[n];
       
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        
        String ans = new String("");
        String res=perm(a,ans,symbol,true,false,0,key);
        if(res.equals("-1"))
        {
            System.out.println("not possible");   
        }
        else
            System.out.println(res);
        for(int i=0;i<n;i++)
        {
            System.out.println(a[i]);
        }
    }
 
    public static String perm(int[] num,String ans,String Symbol,boolean numVer,boolean symVar,int result,int key)
    {
        
         int passresult=result;
         String res ="-1";
        for(int i=0;i<num.length;i++)
         {
             //passresult = result;
           for(int j=0;j<=Symbol.length();j++)
           {
               if(numVer)
               {
                   String ch = ""+num[i];
                   int[] ros = restOfArrey(num,i);
                 //  System.out.println(ans+ch);
                  StringWrapper resu=op(ans,passresult,num[i]);
                   //System.out.println(resu.result+" "+key);
                  if(resu.result == key)
                  {
                      return ans+ch;
                  }
                 res=perm(ros,resu.s,Symbol,false,true,resu.result,key);
                 //return res;
                  if(!res.equals("-1"))
                  {
                      return res;
                  }
               }
               else if(j<Symbol.length()){
                  char ch = Symbol.charAt(j);
                  String ros = Symbol.subSequence(0,j)+Symbol.substring(j+1);
                  res=perm(num,ans+ch,ros,true,false,result,key); 
                  //return res;
                  if(!res.equals("-1"))
                  {
                      return res;
                  }
               }
           }
         }
        
        return res;
    }
    static int[] restOfArrey(int[] num,int i)
        {
         int a[]=new int[num.length-1];
         for(int j=0;j<i;j++)
         {
             a[j]=num[j];
         }
         for(int j=i+1;j<num.length;j++)
         {
             a[j-1]=num[j];
         }
         return a;
        }
    public static StringWrapper op(String ans,int result,int num){
        StringWrapper sw=new StringWrapper();
      
        if(ans.length() <= 1){
            sw.result=num;
            sw.s=ans+num;
            return sw;
        }
        char sym = ans.charAt(ans.length()-1);
        if(sym == '/' && num==0)
        {
            sw.s=ans;
            sw.result=result;
            return sw;
        }
        
        switch(sym){
            case '+':result=result+num;
                     sw.result=result;
                     sw.s="("+ans+num+")";
                     return sw;
            case '-':result=result-num;
                     sw.result=result;
                     sw.s="("+ans+num+")";
                     return sw;
            case '*':result=result*num;
                     sw.result=result;
                     sw.s=ans+num;
                     return sw;
            case '/':result=result/num;
                     sw.result=result;
                     sw.s=ans+num;
                     return sw;
            default :sw.result=result;
                     sw.s=ans;
                     return sw;
        }
           
    }
    
}
class StringWrapper{
    public String s;
    public int result;
    String putString()
    {
        return s;
    }
}